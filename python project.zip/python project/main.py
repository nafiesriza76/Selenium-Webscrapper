from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import time

# Setup Chrome
options = Options()
# options.add_argument("--headless")  # Optional for background run
driver = webdriver.Chrome(options=options)

# Go to JobStreet
driver.get("https://www.jobstreet.com.my/en/job-search/jobs-in-information-technology/")

# Wait until jobTitle anchors appear
WebDriverWait(driver, 15).until(
    EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'a[data-automation="jobTitle"]'))
)

job_cards = driver.find_elements(By.CSS_SELECTOR, 'article[data-automation="normalJob"]')

jobs = []
for card in job_cards:
    try:
        title_element = card.find_element(By.CSS_SELECTOR, '[data-automation="jobTitle"]')
        title = title_element.text.strip()
        link = title_element.get_attribute("href")
    except:
        title, link = "N/A", "N/A"
    
    try:
        location = card.find_element(By.CSS_SELECTOR, '[data-automation="jobLocation"]').text.strip()
    except:
        location = "N/A"
    
    jobs.append({
        "Title": title,
        "Link": link,
        "Location": location
    })

driver.quit()

# Save to Excel
df = pd.DataFrame(jobs)
df.to_excel("jobstreet_titles_only.xlsx", index=False)
print("✅ Scraped", len(jobs), "jobs.")
